<?php


namespace HeroWarsData;

/*
 * TODO:
 * - __construct:
 *     - Make sure primary key is right
 *  - get_columns:
 *     - Make sure column names are correct
 *  - get_install_query
 *     - Make sure column names match get_columns column names
 *     - Make sure primary ID matches
 *     - Make sure FKCs are set up correctly.
 */
class ${NAME} extends Database_Table
{

    function __construct()
    {
        ${DS}this->name = ${DS}this->get_prefix() . '$table_name';
        ${DS}this->primary_key = 'id';
    }


    /**
     * @return array
     */
    function get_columns()
    {
        return [
            'id' => '%d',
            'name' => '%s',
            'med_text' => '%s',
            'enum' => '%s',
            'rank' => '%d',
        ];
    }


    /**
     * @return string
     */
    function get_install_query()
    {
    	global ${DS}wpdb;

	    /** @noinspection SqlNoDataSourceInspection */
	    return "CREATE TABLE {${DS}this->get_name()} (
            id SMALLINT NOT NULL AUTO_INCREMENT,
            name TEXT NOT NULL,
            med_text MEDIUMTEXT,
            enum ENUM ('front','middle','back'),
            rank TINYINT,
            PRIMARY KEY  (id),
            KEY name (name),
            CONSTRAINT name_template2_fkc
            FOREIGN KEY (name)
                REFERENCES {${DS}wpdb->prefix}herowarsdata_template2(name),
            ) {${DS}this->get_collate()};";
    }
}