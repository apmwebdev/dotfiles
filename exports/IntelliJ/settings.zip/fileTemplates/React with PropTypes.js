import React from 'react';
import PropTypes from 'prop-types';

const ${NAME} = (props) => {
  return (
  
  );
}

${NAME}.propTypes = {

};

export default ${NAME};